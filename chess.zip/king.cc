#include "king.h"

King::King(Colour colour, PieceType type): Piece{colour, type}{}

King::~King() {
    
}

