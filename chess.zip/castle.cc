#include "castle.h"

Castle::Castle(Colour colour, PieceType type): Piece{colour, type}{}

Castle::~Castle() {
    
}

