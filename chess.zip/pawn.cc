#include "pawn.h"

Pawn::Pawn(Colour colour, PieceType type): Piece{colour, type}{}

Pawn::~Pawn() {
    
}

