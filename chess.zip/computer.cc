#include "computer.h"

Computer::Computer(int level) {
}

Computer::~Computer() {
    
}

void Computer::undo() {

}

