#include "bishop.h"

Bishop::Bishop(Colour colour, PieceType type): Piece{colour, type}{}

Bishop::~Bishop() {
    
}

