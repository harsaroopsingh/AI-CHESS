#include "nopiece.h"

NoPiece::NoPiece(Colour colour, PieceType type): Piece{colour, type}{}

NoPiece::~NoPiece() {
    
}

