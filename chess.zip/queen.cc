#include "queen.h"

Queen::Queen(Colour colour, PieceType type): Piece{colour, type}{}

Queen::~Queen() {
    
}

