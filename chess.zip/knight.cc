#include "knight.h"

Knight::Knight(Colour colour, PieceType type): Piece{colour, type}{}

Knight::~Knight() {
    
}


