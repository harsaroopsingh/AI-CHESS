#include "human.h"

Human::Human() {

}

Human::~Human() {
    
}

void Human::undo() {

}

