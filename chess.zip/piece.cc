#include "piece.h"

Piece::Piece(Colour colour, PieceType pieceType): colour{colour}, pieceType{pieceType}{}

Piece::~Piece() {

}

