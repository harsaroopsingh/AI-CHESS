#ifndef PLAYER_H
#define PLAYER_H

#include <vector>

class Player {
    public:
        Player();
        ~Player();
        virtual void undo();
};

#endif 

